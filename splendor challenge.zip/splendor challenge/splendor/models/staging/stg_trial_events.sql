-- models/staging/stg_trial_events.sql
-- Staging layer: parse and clean raw trial events
-- Grain: one row per event (after deduplication)

SELECT TABLE_SCHEMA, TABLE_NAME
FROM INFORMATION_SCHEMA.TABLES
WHERE TABLE_TYPE = 'BASE TABLE'
ORDER BY TABLE_NAME;

WITH deduped AS (
    SELECT DISTINCT
        organization_id,
        activity_name,
        timestamp,
        converted,
        converted_at,
        trial_start,
        trial_end
    FROM events_clean
),

typed AS (
    SELECT
        organization_id,
        activity_name,
        CAST(timestamp   AS DATETIME) AS event_at,
        CAST(trial_start AS DATETIME) AS trial_started_at,
        CAST(trial_end   AS DATETIME) AS trial_ended_at,
        CASE WHEN converted = 'True' THEN 1 ELSE 0 END  AS is_converted,
        DATEDIFF(DAY,
            CAST(trial_start AS DATETIME),
            CAST(timestamp   AS DATETIME)
        )  AS trial_day,
        DATEDIFF(DAY,
            CAST(trial_start AS DATETIME),
            CAST(trial_end   AS DATETIME)
        )   AS trial_duration_days
    FROM deduped
),

validated AS (
    SELECT *
    FROM typed
    WHERE trial_day >= 0
      AND trial_day <= 30
)

SELECT * FROM validated
ORDER BY organization_id, event_at;