-- models/staging/stg_organisations.sql

-- models/staging/stg_organisations.sql (SQL Server)
-- Reads directly from events_clean 

WITH

org_spine AS (
    SELECT
        organization_id,
        CAST(MIN(trial_start)  AS DATETIME)              AS trial_started_at,
        CAST(MAX(trial_end)    AS DATETIME)              AS trial_ended_at,
        MAX(converted)                                   AS is_converted,
        CAST(MAX(converted_at) AS DATETIME)              AS converted_at,

        -- Total event volume in trial
        COUNT(*)                                         AS total_events,

        -- Distinct activity types used
        COUNT(DISTINCT activity_name)                    AS unique_activities_used,

        -- Number of distinct days active
        COUNT(DISTINCT CAST(timestamp AS DATE))          AS active_days,

        -- First and last event days
        MIN(days_into_trial)                             AS first_event_day,
        MAX(days_into_trial)                             AS last_event_day

    FROM events_clean
    GROUP BY organization_id
),

enriched AS (
    SELECT
        *,

        -- Days from trial start to conversion (NULL for non-converters)
        DATEDIFF(DAY, trial_started_at, converted_at)   AS days_to_convert,

        -- Events per active day (engagement intensity)
        ROUND(
            CAST(total_events AS FLOAT) / NULLIF(active_days, 0),
            2
        )                                                AS events_per_active_day,

        -- Trial duration sanity check (should always be 30)
        DATEDIFF(DAY, trial_started_at, trial_ended_at) AS trial_duration_days

    FROM org_spine
)

SELECT * FROM enriched
ORDER BY organization_id;
