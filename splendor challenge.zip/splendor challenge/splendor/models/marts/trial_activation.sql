-- trial_activation.sql (SQL Server)

SELECT *
FROM trial_goals

WITH goals_wide AS (
    SELECT
        organization_id,

        -- G1: >= 3 shifts created in first 14 trial days
        CASE WHEN SUM(CASE WHEN activity_name = 'Scheduling.Shift.Created'
                            AND days_into_trial <= 14 THEN 1 ELSE 0 END) >= 3
             THEN 1 ELSE 0 END                                            AS g1_schedule_builder,

        -- G2: at least 1 mobile schedule load
        CASE WHEN SUM(CASE WHEN activity_name = 'Mobile.Schedule.Loaded'
                           THEN 1 ELSE 0 END) >= 1
             THEN 1 ELSE 0 END                                            AS g2_mobile_adoption,

        -- G3: at least 1 punch clock in
        CASE WHEN SUM(CASE WHEN activity_name = 'PunchClock.PunchedIn'
                           THEN 1 ELSE 0 END) >= 1
             THEN 1 ELSE 0 END                                            AS g3_clock_activated,

        -- G4: at least 1 shift approved
        CASE WHEN SUM(CASE WHEN activity_name = 'Scheduling.Shift.Approved'
                           THEN 1 ELSE 0 END) >= 1
             THEN 1 ELSE 0 END                                            AS g4_approval_workflow,

        -- G5: bulk timesheet OR Xero sync (aspirational)
        CASE WHEN SUM(CASE WHEN activity_name IN (
                                'Timesheets.BulkApprove.Confirmed',
                                'Integration.Xero.PayrollExport.Synced')
                           THEN 1 ELSE 0 END) >= 1
             THEN 1 ELSE 0 END                                            AS g5_payroll_loop,

        -- Goal completion timestamps (first event that satisfies each goal)
        MIN(CASE WHEN activity_name = 'Scheduling.Shift.Created'
                  AND days_into_trial <= 14
                 THEN CAST(timestamp AS DATETIME) END)                    AS g1_completed_at,
        MIN(CASE WHEN activity_name = 'Mobile.Schedule.Loaded'
                 THEN CAST(timestamp AS DATETIME) END)                    AS g2_completed_at,
        MIN(CASE WHEN activity_name = 'PunchClock.PunchedIn'
                 THEN CAST(timestamp AS DATETIME) END)                    AS g3_completed_at,
        MIN(CASE WHEN activity_name = 'Scheduling.Shift.Approved'
                 THEN CAST(timestamp AS DATETIME) END)                    AS g4_completed_at,
        MIN(CASE WHEN activity_name IN (
                        'Timesheets.BulkApprove.Confirmed',
                        'Integration.Xero.PayrollExport.Synced')
                 THEN CAST(timestamp AS DATETIME) END)                    AS g5_completed_at,

        -- Org metadata
        CAST(MIN(trial_start) AS DATETIME)                                AS trial_started_at,
        CAST(MAX(trial_end)   AS DATETIME)                                AS trial_ended_at,
        MAX(converted)                                                     AS is_converted,
        COUNT(*)                                                           AS total_events,
        COUNT(DISTINCT CAST(timestamp AS DATE))                           AS active_days

    FROM events_clean
    GROUP BY organization_id
),

last_goal_completed AS (
    SELECT
        organization_id,
        (
            SELECT MAX(v) FROM (VALUES
                (g1_completed_at),
                (g2_completed_at),
                (g3_completed_at),
                (g4_completed_at)
            ) AS t(v)
        ) AS activated_at
    FROM goals_wide
),

final AS (
    SELECT
        gw.organization_id,
        gw.is_converted,
        gw.g1_schedule_builder,
        gw.g2_mobile_adoption,
        gw.g3_clock_activated,
        gw.g4_approval_workflow,
        gw.g5_payroll_loop,
        gw.g1_completed_at,
        gw.g2_completed_at,
        gw.g3_completed_at,
        gw.g4_completed_at,
        gw.g5_completed_at,

        -- Total goals completed (all 5)
        gw.g1_schedule_builder + gw.g2_mobile_adoption
        + gw.g3_clock_activated + gw.g4_approval_workflow
        + gw.g5_payroll_loop                                              AS goals_completed_count,

        -- Trial Activation: all 4 core goals (G5 aspirational)
        CASE
            WHEN gw.g1_schedule_builder  = 1
             AND gw.g2_mobile_adoption   = 1
             AND gw.g3_clock_activated   = 1
             AND gw.g4_approval_workflow = 1
            THEN 1 ELSE 0
        END                                                               AS is_activated,

        -- Activation timestamp
        CASE
            WHEN gw.g1_schedule_builder  = 1
             AND gw.g2_mobile_adoption   = 1
             AND gw.g3_clock_activated   = 1
             AND gw.g4_approval_workflow = 1
            THEN lgc.activated_at
        END                                                               AS activated_at,

        -- Days to activation
        CASE
            WHEN gw.g1_schedule_builder  = 1
             AND gw.g2_mobile_adoption   = 1
             AND gw.g3_clock_activated   = 1
             AND gw.g4_approval_workflow = 1
            THEN DATEDIFF(DAY, gw.trial_started_at, lgc.activated_at)
        END                                                               AS days_to_activation,

        gw.trial_started_at,
        gw.trial_ended_at,
        gw.total_events,
        gw.active_days,
        DATEDIFF(DAY, gw.trial_started_at, gw.trial_ended_at)            AS days_to_convert

    FROM goals_wide gw
    INNER JOIN last_goal_completed lgc ON gw.organization_id = lgc.organization_id
)

SELECT *
FROM final
ORDER BY is_activated DESC, goals_completed_count DESC;