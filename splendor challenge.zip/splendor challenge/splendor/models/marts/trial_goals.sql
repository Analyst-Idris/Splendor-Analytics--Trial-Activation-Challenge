﻿-- models/marts/trial_goals.sql
-- Mart: tracks whether each trialist organisation has completed each trial goal
-- Grain: one row per (organization_id, goal_name)
--
-- Trial Goals (evidence-backed from conversion driver analysis):
--
-- G1  schedule_builder   : Created ≥ 3 shifts within first 14 trial days
-- G2  mobile_adoption    : Loaded schedule on mobile at least once
-- G3  clock_activated    : Performed at least 1 punch-clock check-in
-- G4  approval_workflow  : Had at least 1 shift approved
-- G5  payroll_loop       : Confirmed bulk timesheets OR synced Xero payroll



WITH

-- Goal 1: Schedule builder
-- 3rd shift creation timestamp = goal completion moment
g1 AS (
    SELECT
        organization_id,
        CASE WHEN COUNT(*) >= 3 THEN 1 ELSE 0 END          AS goal_completed,
        MIN(event_at)                                        AS first_qualifying_event_at,
        MIN(CASE WHEN rn = 3 THEN event_at END)             AS goal_completed_at
    FROM (
        SELECT
            organization_id,
            CAST(timestamp AS DATETIME) AS event_at,
            ROW_NUMBER() OVER (
                PARTITION BY organization_id
                ORDER BY CAST(timestamp AS DATETIME)
            )  AS rn
        FROM events_clean
        WHERE activity_name = 'Scheduling.Shift.Created'
          AND days_into_trial <= 14
    ) ranked
    GROUP BY organization_id
),

-- Goal 2: Mobile adoption
g2 AS (
    SELECT
        organization_id,
        1   AS goal_completed,
        MIN(CAST(timestamp AS DATETIME)) AS goal_completed_at
    FROM events_clean
    WHERE activity_name = 'Mobile.Schedule.Loaded'
    GROUP BY organization_id
),

--  Goal 3: Clock activated
g3 AS (
    SELECT
        organization_id,
        1  AS goal_completed,
        MIN(CAST(timestamp AS DATETIME)) AS goal_completed_at
    FROM events_clean
    WHERE activity_name = 'PunchClock.PunchedIn'
    GROUP BY organization_id
),

--  Goal 4: Approval workflow 
g4 AS (
    SELECT
        organization_id,
        1  AS goal_completed,
        MIN(CAST(timestamp AS DATETIME)) AS goal_completed_at
    FROM events_clean
    WHERE activity_name = 'Scheduling.Shift.Approved'
    GROUP BY organization_id
),

--  Goal 5: Payroll loop 
g5 AS (
    SELECT
        organization_id,
        1 AS goal_completed,
        MIN(CAST(timestamp AS DATETIME)) AS goal_completed_at
    FROM events_clean
    WHERE activity_name IN (
        'Timesheets.BulkApprove.Confirmed',
        'Integration.Xero.PayrollExport.Synced'
    )
    GROUP BY organization_id
),

-- Org spine 
-- One row per org with trial metadata
orgs AS (
    SELECT
        organization_id,
        MAX(converted) AS is_converted,
        CAST(MIN(trial_start) AS DATETIME) AS trial_started_at,
        CAST(MAX(trial_end)   AS DATETIME) AS trial_ended_at
    FROM events_clean
    GROUP BY organization_id
),

--  Unpivot goals to long format
-- Every org appears for every goal (even if not completed)
goals_long AS (

    SELECT
        o.organization_id,
        'G1_schedule_builder'  AS goal_name,
        COALESCE(g1.goal_completed, 0) AS goal_completed,
        g1.goal_completed_at
    FROM orgs o
    LEFT JOIN g1 ON g1.organization_id = o.organization_id

    UNION ALL

    SELECT
        o.organization_id,
        'G2_mobile_adoption',
        COALESCE(g2.goal_completed, 0),
        g2.goal_completed_at
    FROM orgs o
    LEFT JOIN g2 ON g2.organization_id = o.organization_id

    UNION ALL

    SELECT
        o.organization_id,
        'G3_clock_activated',
        COALESCE(g3.goal_completed, 0),
        g3.goal_completed_at
    FROM orgs o
    LEFT JOIN g3 ON g3.organization_id = o.organization_id

    UNION ALL

    SELECT
        o.organization_id,
        'G4_approval_workflow',
        COALESCE(g4.goal_completed, 0),
        g4.goal_completed_at
    FROM orgs o
    LEFT JOIN g4 ON g4.organization_id = o.organization_id

    UNION ALL

    SELECT
        o.organization_id,
        'G5_payroll_loop',
        COALESCE(g5.goal_completed, 0),
        g5.goal_completed_at
    FROM orgs o
    LEFT JOIN g5 ON g5.organization_id = o.organization_id
)

-- Final output 
SELECT
    gl.organization_id,
    gl.goal_name,
    gl.goal_completed,
    gl.goal_completed_at,

    -- Days into trial when goal was completed (NULL = not completed)
    DATEDIFF(DAY, o.trial_started_at, gl.goal_completed_at) AS goal_completion_day,

    -- Context
    o.is_converted,
    o.trial_started_at,
    o.trial_ended_at

FROM goals_long gl
INNER JOIN orgs o ON gl.organization_id = o.organization_id
ORDER BY gl.organization_id, gl.goal_name;
